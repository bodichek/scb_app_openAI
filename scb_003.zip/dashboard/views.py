from __future__ import annotations

from collections import defaultdict

from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render

from ingestion.models import ExtractedRow, ExtractedTable


@login_required
def index(request):
    # Limit all dashboard data to the current user's documents
    table_columns = ExtractedTable.objects.filter(
        document__owner=request.user
    ).values_list("columns", flat=True)

    known_columns = set()
    for column_list in table_columns:
        if not column_list:
            continue
        for column in column_list:
            known_columns.add(column)
    known_columns = sorted(known_columns)

    group_by = request.GET.get("group_by")
    value_col = request.GET.get("value_col")
    agg = request.GET.get("agg", "count")

    if group_by not in known_columns:
        group_by = None
    if value_col not in known_columns:
        value_col = None
    if agg not in {"count", "sum", "avg"}:
        agg = "count"

    chart = None
    if group_by:
        row_dicts = ExtractedRow.objects.filter(
            table__document__owner=request.user
        ).values_list("data", flat=True)
        data = [row for row in row_dicts if isinstance(row, dict) and row.get(group_by) is not None]

        groups = defaultdict(list)
        for row in data:
            groups[row.get(group_by)].append(row)

        labels: list[str] = []
        values: list[float] = []

        if agg == "sum" and value_col:
            for key, items in groups.items():
                total = 0.0
                for item in items:
                    value = item.get(value_col)
                    if isinstance(value, (int, float)):
                        total += float(value)
                labels.append(str(key))
                values.append(total)
        elif agg == "avg" and value_col:
            for key, items in groups.items():
                numbers = [float(item.get(value_col)) for item in items if isinstance(item.get(value_col), (int, float))]
                labels.append(str(key))
                values.append(sum(numbers) / len(numbers) if numbers else 0.0)
        else:  # count
            for key, items in groups.items():
                labels.append(str(key))
                values.append(len(items))

        chart = {
            "labels": labels,
            "values": values,
            "title": f"{agg.upper()} by {group_by}" if not value_col else f"{agg.upper()} {value_col} by {group_by}",
        }

    return render(
        request,
        "dashboard/index.html",
        {
            "known_columns": known_columns,
            "group_by": group_by,
            "value_col": value_col,
            "agg": agg,
            "chart": chart,
        },
    )


@login_required
def dashboard_view(request):
    return redirect("dashboard")
