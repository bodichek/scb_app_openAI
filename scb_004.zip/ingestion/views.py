from __future__ import annotations
from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpRequest, HttpResponse
from django.contrib import messages
from django.db import transaction
from django.contrib.auth.decorators import login_required
from .forms import MultiUploadForm
from .models import Document, ExtractedTable, ExtractedRow

import io
import re
import pandas as pd

# Extraction libraries
import camelot
import pdfplumber


def _clean_headers(df: pd.DataFrame) -> pd.DataFrame:
    # If columns look like 0..N, try to use the first non-empty row as header
    if all(isinstance(c, int) for c in df.columns):
        # find first row with at least one non-empty value
        header_idx = None
        for i, row in df.iterrows():
            if any((str(x).strip() != "" and str(x).strip().lower() != "nan") for x in row.tolist()):
                header_idx = i
                break
        if header_idx is not None:
            new_cols = [str(x).strip() for x in df.iloc[header_idx].tolist()]
            df = df.iloc[header_idx + 1 :].reset_index(drop=True)
            df.columns = new_cols

    def normalize(name: str) -> str:
        s = re.sub(r"\s+", " ", str(name or "").strip())
        s = s.lower()
        s = re.sub(r"[^a-z0-9 _-]", "", s)
        s = s.replace(" ", "_")
        return s or "col"

    df.columns = [normalize(c) for c in df.columns]
    return df


def _clean_cells(df: pd.DataFrame) -> pd.DataFrame:
    def clean_val(v):
        if pd.isna(v):
            return None
        s = str(v).strip()
        s = re.sub(r"\s+", " ", s)
        if s == "" or s.lower() == "nan":
            return None
        # normalize numbers
        sn = s.replace(",", "")
        if re.fullmatch(r"-?\d+(\.\d+)?", sn):
            try:
                return float(sn)
            except Exception:
                pass
        return s

    return df.applymap(clean_val)


def _drop_empty(df: pd.DataFrame) -> pd.DataFrame:
    df = df.dropna(axis=0, how="all")
    df = df.dropna(axis=1, how="all")
    df = df.reset_index(drop=True)
    return df


def _df_to_rows(df: pd.DataFrame) -> list[dict]:
    rows: list[dict] = []
    for _, r in df.iterrows():
        row = {}
        for c in df.columns:
            row[str(c)] = r[c] if pd.notna(r[c]) else None
        rows.append(row)
    return rows


def _extract_with_camelot(path: str) -> list[dict]:
    tables = []
    try:
        # lattice first
        latt = camelot.read_pdf(path, flavor="lattice", pages="all")
        for i in range(latt.n):
            df = latt[i].df
            tables.append({"df": df, "method": "camelot-lattice", "page": latt[i].page})
    except Exception:
        pass

    try:
        # then stream
        stream = camelot.read_pdf(path, flavor="stream", pages="all")
        for i in range(stream.n):
            df = stream[i].df
            tables.append({"df": df, "method": "camelot-stream", "page": stream[i].page})
    except Exception:
        pass

    return tables


def _extract_with_pdfplumber(path: str) -> list[dict]:
    tables = []
    try:
        with pdfplumber.open(path) as pdf:
            for pageno, page in enumerate(pdf.pages, start=1):
                try:
                    tbs = page.extract_tables()
                    for idx, tb in enumerate(tbs):
                        df = pd.DataFrame(tb)
                        tables.append({"df": df, "method": "pdfplumber", "page": pageno})
                except Exception:
                    continue
    except Exception:
        pass
    return tables


@login_required
@transaction.atomic
def upload_pdf(request):
    if request.method == 'POST' and request.FILES.get('pdf_file'):
        pdf_file = request.FILES['pdf_file']
        
        try:
            # Vytvoření dokumentu
            doc = Document.objects.create(
                file=pdf_file,
                original_filename=pdf_file.name
            )
            
            # Zpracování PDF
            with pdfplumber.open(pdf_file) as pdf:
                for page in pdf.pages:
                    tables = page.extract_tables()
                    if len(tables) > 0:
                        for table_data in tables:
                            if table_data and len(table_data) > 0:
                                ExtractedTable.objects.create(
                                    document=doc,
                                    data=table_data
                                )
            
            messages.success(request, "PDF bylo úspěšně nahráno")
            return redirect('ingestion:upload')
                    
        except Exception as e:
            messages.error(request, f"Chyba při zpracování PDF: {str(e)}")
            return redirect('ingestion:upload')

    return render(request, 'ingestion/upload.html')


@login_required
def documents(request: HttpRequest) -> HttpResponse:
    docs = Document.objects.filter(owner=request.user).order_by("-uploaded_at")
    return render(request, "ingestion/documents.html", {"documents": docs})


@login_required
def document_detail(request: HttpRequest, doc_id: int) -> HttpResponse:
    doc = get_object_or_404(Document, id=doc_id, owner=request.user)
    return render(request, "ingestion/document_detail.html", {"doc": doc})


@login_required
def table_detail(request: HttpRequest, table_id: int) -> HttpResponse:
    table = get_object_or_404(ExtractedTable, id=table_id, document__owner=request.user)
    return render(request, "ingestion/table_detail.html", {"table": table})
